1.the code for validating zip code can be shorter by improve the regular expression
2.i have write another regular expression for the email address
3.there are a mistake when use fwrite() save the data into txt file.