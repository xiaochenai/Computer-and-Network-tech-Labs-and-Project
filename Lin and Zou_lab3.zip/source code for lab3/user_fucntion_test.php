<?php
include 'html_functions.inc';

// The title on my page should be
// My New Website
html_headers("My New Website");

echo "The HTML header tags were printed by a subroutine";
echo "</body></html>";
?>