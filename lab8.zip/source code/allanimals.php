<html>
<head>
<title>Here are the animals</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<body>

<?php
// This file returns an image corresponding to the animal id passed to it.
// Connect to the mySQL server and select our database
$dbcnx = mysql_connect("localhost", "root","lx64498908") or die("Could not connect to the database server.");
mysql_select_db("pet_store",$dbcnx) or die("Can not select database");


$query =	"	SELECT	*
				FROM	animals
			";
// Actually run the query
$result = mysql_query($query) or die(mysql_error());
$number_cols = mysql_num_fields($result);
echo "<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"5\" align=\"center\">";
// This next line creates an array called $row which will
// contain all of the items in a row returned by the mySQL
// query
while ($row = mysql_fetch_row($result))
{
echo "<tr>";
echo "<td>";
//display animal image
echo "<IMG SRC=\"display_animal.php?animal_id=$row[0]\">";
echo "</td>";
echo "<td>$row[1]</td>";
echo "<td>$row[2]</td>";
echo "<td>$row[3]</td>";
echo "<td>$row[4]</td>";

echo "</tr>";
}
echo "</table><br><br>";

?>
</body>
</html>