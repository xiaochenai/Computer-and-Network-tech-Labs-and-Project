<?php
// This file returns an image corresponding to the animal id passed to it.
// Connect to the mySQL server and select our database
$dbcnx = mysql_connect("localhost", "root","lx64498908") or die("Could not connect to the database server.");
mysql_select_db("store",$dbcnx) or die("Can not select database");
// Now let's do our mySQL query to lookup the information

if(isset($_GET['name']))
{
$query = "SELECT image FROM phone WHERE Name=\"$_GET[name]\"";
}
//album_pic = blob
// We needed the slashes (\) to go with the PHP syntax, but
// to actually complete the query we need to get rid of them.
$query = stripslashes($query);
// Actually run the query
$result = mysql_query($query) or die(mysql_error());
$row = mysql_fetch_row($result);
//image type
header('Content-type: image/jpeg');
echo "$row[0]";	
//echo "Imagejpeg($row[$i])";
?>